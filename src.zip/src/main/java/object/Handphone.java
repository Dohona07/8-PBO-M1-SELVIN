package object;

public class Handphone {
    // atribut
    String merk;
    String tipe;
    int harga;

    // constructor
    public Handphone(String merk, String tipe, int harga) {
        this.merk = merk;
        this.tipe = tipe;
        this.harga = harga;
    }

    // method tampil data
    public void tampilData() {
        System.out.println("Merk  : " + merk);
        System.out.println("Tipe  : " + tipe);
        System.out.println("Harga : " + harga);
    }
}
