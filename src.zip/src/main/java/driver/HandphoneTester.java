package driver;

import object.Handphone;

public class HandphoneTester {
    public static void main(String[] args) {

        // membuat object
        Handphone hp1 = new Handphone("Samsung", "S23", 12000000);
        Handphone hp2 = new Handphone("Xiaomi", "Redmi Note 12", 3000000);

        // tampilkan data
        System.out.println("Data Handphone 1:");
        hp1.tampilData();

        System.out.println("\nData Handphone 2:");
        hp2.tampilData();
    }
}